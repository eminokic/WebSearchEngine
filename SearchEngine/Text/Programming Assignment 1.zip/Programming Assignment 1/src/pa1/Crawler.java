package pa1;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.UnsupportedMimeTypeException;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import api.Graph;
import api.Util;

/**
 * Implementation of a basic web crawler that creates a graph of some portion of
 * the world wide web.
 *
 * @author Josh Loftus and Emin Oick
 */
public class Crawler {

	private int maxDepth, maxPages, connectionCount = 0;
	private String seedUrl;
	protected static boolean full;
	protected MyGraph<String> graph;
	private Queue<String> toProcessQueue;
	private Set<String> visitedSet;

	/**
	 * Constructs a Crawler that will start with the given seed url, including only
	 * up to maxPages pages at distance up to maxDepth from the seed url.
	 */
	public Crawler(String seedUrl, int maxDepth, int maxPages) {
		this.seedUrl = seedUrl;
		this.maxDepth = maxDepth;
		this.maxPages = maxPages;
		this.graph = new MyGraph<String>();
		this.toProcessQueue = new ArrayDeque<>();
		this.visitedSet = new HashSet<>();
	}

	/**
	 * Creates a web graph for the portion of the web obtained by a BFS of the web
	 * starting with the seed url for this object, subject to the restrictions
	 * implied by maxDepth and maxPages.
	 * 
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public Graph<String> crawl() {
		String currentUrl, currentLink;
		int i, depth;
		boolean isFull, doneLoading, valid;
		Elements elmts;
		List<String> links;
		@SuppressWarnings("unused")
		Document doc, tmp;

		currentUrl = this.seedUrl;
		isFull = false;
		doc = null;
		depth = 0;
		toProcessQueue.add(currentUrl);
		toProcessQueue.add("!");
		
		while (toProcessQueue.size() > 1 && depth < maxDepth) {
			links = new ArrayList<>();
			visitedSet.add(currentUrl);
			graph.addVertex(currentUrl);
			connectionCount++;
			try {
				if (connectionCount >= 50) {
					Thread.sleep(3000);
					connectionCount = 0;
				}
			} catch (InterruptedException ignore) {
			}
			try {
				doc = Jsoup.connect(currentUrl).get();
			} catch (HttpStatusException ignore) {
			} catch (UnsupportedMimeTypeException ignore) {
			} catch (IOException ignore) {}
			elmts = doc.select("a[href]");
			for (Element e : elmts) {
				if (!links.contains(e.attr("abs:href")))
					links.add(e.attr("abs:href"));
			}
			i = 0;
			doneLoading = false;
			
			while ((graph.V.size() < maxPages) && i < links.size()) {
				if (!Util.ignoreLink(currentUrl, links.get(i))) {
					valid = true;
					currentLink = links.get(i);
					connectionCount++;
					try {
						if (connectionCount >= 50) {
							Thread.sleep(3000);
							connectionCount = 0;
						}
					} catch (InterruptedException ignore) {}
					try {
						tmp = Jsoup.connect(currentLink).get();
					} catch (HttpStatusException ignore) {
						valid = false;
					} catch (UnsupportedMimeTypeException ignore) {
						valid = false;
					} catch (IOException ignore) {
						valid = false;
					}
					if (valid) {
						graph.addVertex(currentLink);
						if (!visitedSet.contains(currentLink) && !toProcessQueue.contains(currentLink))
							toProcessQueue.add(currentLink);
						graph.addEdge(currentUrl, currentLink);
						if (graph.V.size() >= maxPages) {
							doneLoading = true;
							full = true;
						}
					}
				}
				i++;
			}

			if (graph.V.size() >= maxPages)
				isFull = true;
			if (doneLoading) {
				while (i < links.size()) {
					if (toProcessQueue.contains(links.get(i)))
						graph.addEdge(currentUrl, links.get(i));
					i++;
				}
				isFull = false;
			}
			if (isFull)
				graph.addAllEdges(currentUrl, links);
			toProcessQueue.remove(currentUrl);
			currentUrl = toProcessQueue.peek();
			if (currentUrl.equals("!")) {
				depth++;
				toProcessQueue.remove(currentUrl);
				currentUrl = toProcessQueue.peek();
				toProcessQueue.add("!");
			}
		}
		return graph;
	}
}
