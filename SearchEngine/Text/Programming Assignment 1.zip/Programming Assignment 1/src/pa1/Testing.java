package pa1;

import java.util.List;

import api.TaggedVertex;

public class Testing {

	public static void main(String[] args) {
		String base = "http://web.cs.iastate.edu/~smkautz/cs311f19/temp/a.html";
		Crawler crawler = new Crawler(base, 4, 25);
		MyGraph<String> graph = (MyGraph<String>) crawler.crawl();
		Index i = new Index(graph.vertexDataWithIncomingCounts());
		i.makeIndex();
		List<TaggedVertex<String>> lst = i.search("chicken");
		for (TaggedVertex<String> a : lst)
			System.out.println("Testing: " + a.getVertexData() + ": " + a.getTagValue());
	}
}
